<?php $__env->startSection('dashboard-content'); ?>
    <div class="row">
        <div class="col-sm-6">
            <div class="card border-0 shadow" style="background: #fff;">
                <div class="card-body">
                    <h1>Jumlah Mahasiswa <?php echo e(count($user)); ?></h1>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card border-0 shadow" style="background: #fff;">
                <div class="card-body">
                    <h1>Mahasiswa yang sudah mengisi biodata <?php echo e(count($biodata)); ?></h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arie/project_gis/resources/views/dashboard/admin/index.blade.php ENDPATH**/ ?>