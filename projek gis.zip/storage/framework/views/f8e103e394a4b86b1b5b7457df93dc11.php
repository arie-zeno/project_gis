<?php $__env->startSection('dashboard-content'); ?>
    <div class="row">

        <div class="col-sm-12">
            <div class="card border-0 shadow" style="background: #fff;">
                <div class="card-body">
                    <div id="toolbar">
                        <h4>Data mahasiswa</h4>
                    </div>

                    <table data-toggle="table" data-search="true" data-toolbar="#toolbar" >
                        <thead>
                            <tr class="text-center">
                                <th>Nama</th>
                                <th>NIM</th>
                                <th>Angkatan</th>
                                <th>Operasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $biodata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->nim); ?></td>
                                    <td><?php echo e($item->angkatan); ?></td>
                                    <td class="text-center"><button class="btn btn-sm btn-danger">Hapus</button></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        function buttons() {
            return {
                btnUsersAdd: {
                    text: 'Highlight Users',
                    icon: 'bi-arrow-down',
                    event: function() {
                        alert('Do some stuff to e.g. search all users which has logged in the last week')
                    },
                    attributes: {
                        title: 'Search all users which has logged in the last week'
                    }
                },
                btnAdd: {
                    text: 'Add new row',
                    icon: 'bi-arrow-clockwise',
                    event: function() {
                        alert('Do some stuff to e.g. add a new row')
                    },
                    attributes: {
                        title: 'Add a new row to the table'
                    }
                }
            }

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arie/project_gis/resources/views/dashboard/admin/mahasiswa.blade.php ENDPATH**/ ?>