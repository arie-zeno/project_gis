<?php $__env->startSection('dashboard-content'); ?>
    <?php if($biodata != null): ?>
        <div class="card border-0 shadow" style="background: #fff;">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-2">
                        <img src="<?php echo e($biodata->foto ? asset('storage/'.$biodata->foto) : asset('img/il_1.svg')); ?>" class="img-fluid rounded shadow" alt="..." style="max-height: 300px">
                    </div>
                    <div class="col-sm-4 d-flex flex-column justify-content-center">
                        <h2 class="fw-light"><?php echo e($biodata->nama); ?></h2>
                        <h5 class="fw-light mb-4"><?php echo e($biodata->nim); ?> </h5>
                        <table>
                            <tr>
                                <td class="fw-bold" style="width: 200px">Angkatan</td>
                                <td style="width: 300px"><?php echo e($biodata->angkatan); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 200px">Provinsi</td>
                                <td style="width: 300px"><?php echo e($biodata->provinsi); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 200px">Kabupaten/Kota</td>
                                <td style="width: 300px"><?php echo e($biodata->kabupaten); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 200px">Kecamatan</td>
                                <td style="width: 300px"><?php echo e($biodata->kecamatan); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-bold" style="width: 200px">Kelurahan</td>
                                <td style="width: 300px"><?php echo e($biodata->kelurahan); ?></td>
                            </tr>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    <?php else: ?>
        <div class="card border-0 shadow" style="background: #fff;">
            <div class="card-body">
                <h2>Anda belum mengisi biodata, <a href="<?php echo e(route('isi.biodata')); ?>">isi biodata</a></h2>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arie/project_gis/resources/views/dashboard/mahasiswa/biodata.blade.php ENDPATH**/ ?>